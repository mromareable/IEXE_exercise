# x = 0
# if x < 10:
#     print("Hola!")
#     x = x + 1
#     print(x)


x = 0
while x < 10:
    print("Hola!",x)
    x = x + 1