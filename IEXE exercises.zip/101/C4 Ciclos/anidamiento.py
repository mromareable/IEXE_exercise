for letra in ['a', 'b', 'c', 'd', 'e']:
  for num in range(1, 6):
    for signo in ['>', '.', '!', '+', '#']:
      print('El signo es ' + signo + ', el numero es ' + str(num) + ' y la letra es ' + letra)