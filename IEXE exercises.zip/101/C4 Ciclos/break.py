x = 0
while True:
    print("Hola!",x)
    x = x + 1
    if x == 9:
        break
print("x = ",x)