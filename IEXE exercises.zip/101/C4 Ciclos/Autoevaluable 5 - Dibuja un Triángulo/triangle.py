# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Primero toma unos minutos para encontrar un patrón en los espacios y 
# el número de asteriscos.

# Si la base es 1:
#*

# Si la base es 3:
# *
#***

# Si la base es 5:
#  *
# ***
#*****

# Si la base es 7:
#   *
#  ***
# *****
#*******

# Captura el tamaño de la base:
base = int(input())
# Prmero valida que la base sea un número impar. Usa el operador %

# Para dibujar el triángulo vas a necesitar dos ciclos:
#   - Uno que controla la línea
#   - Un ciclo anidado que controla los espacios y los asteriscos
while(base % 2 == 0):    
    print('Ingrese un numero valido: ')
    base = int(input())

for i in range(1,int(base/2)+2): # controla la línea
    for j in range(1,base+1):
        print(('*'*(i)+'*'*(i-1)).center(base,' '),end='')
        break
    print()
