# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Usa la función range() para imprimir una enumeración que comienza en 10 y
# termina en 100 con incrementos 1
#print(list(...))  # descomenta y modifica esta línea
for x in range (10, 100):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en 10 y
# termina en 100 con incrementos 5
#print(list(...))  # descomenta y modifica esta línea
for x in range (10, 100,5):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en -10 y
# termina en 0 con incrementos 1
#print(list(...))  # descomenta y modifica esta línea
for x in range (-10, 0, 1):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en -100 y
# termina en 0 con incrementos 10
#print(list(...))  # descomenta y modifica esta línea
for x in range (-100, 0, 10):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en 100 y
# termina en 0 con decrementos 1
#print(list(...))  # descomenta y modifica esta línea
for x in range (100, 0, -1):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en 100 y
# termina en 0 con decrementos 10
#print(list(...))  # descomenta y modifica esta línea
for x in range (100, 0, -10):
    print(x)
# Usa la función range() para imprimir una enumeración que comienza en 100 y
# termina en -100 con decrementos 20
#print(list(...))  # descomenta y modifica esta línea
for x in range (100, -100, -20):
    print(x)
# Usa la función len() y range() para imprimir la longitud de una enumeración
# de 100 elementos
#print(len(...))  # descomenta y modifica esta línea
list_1 = []
for x in range (0, 100):
    list_1.append(x)
print(len(list_1))
# Usa la función len() y range() para imprimir la longitud de una enumeración
# de 1000 elementos
#print(len(...))  # descomenta y modifica esta línea
list_2 = []
for x in range (0, 1000):
    list_2.append(x)
print(len(list_2))
# Usa la función len() y range() para imprimir la longitud de una enumeración
# de 0 elementos
#print(len(...))  # descomenta y modifica esta línea
list_3 = []
for x in range (0, 0):
    list_3.append(x)
print(len(list_3))