for x in range(100):
    if x % 3 == 0 and x % 5 == 0:
        print("No me gustan los multiplos de 3 y 5")
        continue
    if x % 10 == 0:
        print(str(x) + " es multiplo de 10")