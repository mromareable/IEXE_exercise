import random
x = random.randint(1, 11)
print("Adivina el numero entre 1 y 10")
guess = int(input())
while guess != x:
    if guess < x:
        print("El numero es mayor")
    else:
        print("El numero es menor")
    print("Vuelve a intentarlo")
    guess = int(input())
else:
    print("Adivinaste!")