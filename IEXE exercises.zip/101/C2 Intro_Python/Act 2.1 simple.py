# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Este es un comentario de Python. Los comentarios comienzan con el símbolo '#' 
# y Python ignora todo lo que se encuentra a la derecha del símbolo '#'

# En este editor de texto puedes modificar el código. Como vimos en la lección,
# un programa se compone de múltiples sentencias o instrucciones que el
# intérprete de Python va a ejecutar en orden.

# Ahora, grega una letra después de esta línea:
# l
# Se activó el botón de guardar. Guarda el código y ejecútalo

# No pasó nada por que no hay ninguna instrucción. Hasta ahora todos son
# comentarios como este. Descomenta el '#' al principio de la siguiente línea,
# guarda tus cambios y ejecuta el programa.

4+5 # El resto de esta linea no se ejecuta por que está a la derecha del '#'

# El intérprete ejecutó la suma de 4 y 5, pero aún no aparece nada. El resultado
# se perdió en la ejecución.

# ahora descomenta la siguiente línea y ejecuta el programa.

print(4+5)

# El intérprete ejecutó la instrucción e imprimió el valor de '9'. Nota que
# no imprimió la cadena '4+5'. Esto es por que primero el intérprete evaluó el 
# resultado de la suma y después lo imprimió.

# Ahora declaremos una variable. Descomenta la siguiente línea y ejecuta el
# programa.

suma = 4 + 5

# Pasó lo mismo, el resultado de la suma de 4 y 5 se guardó en la variable de
# nombre 'suma'. Si quieres desplegar el resultado usa la instrucción print:

print(suma)

# Ahora se imprimió el contenido de la variable 'suma', que contiene el 
# resultado de evaluar la suma de 4 + 5.
