# # ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# --------------------------------------------------------------------------------

# Ahora ahora veamos los operadores de comparación: menor que (<), mayor que (>),
# menor que (<=), mayor que (>=), igualdad (==) y desigualdad (!=)

# El funcionamiento de estos operadores es intiutivo. Comparan los valores en
# ambos lados del operador y evalúan o devuelven un valor Booleano.

# Descomenta las siguientes líneas y ejecuta el programa
print('1 < 2:', 1 < 2)
print('1 <= 2:', 1 <= 2)
print('1 > 2:', 1 > 2)
print('1 >= 2:', 1 >= 2)
print('1 == 2:', 1 == 2)
print('1 != 2:', 1 != 2)

# Al igual que los operadores aritméticos, puedes usar valores enteros y de 
# punto flotante indistintamente.

print('1.0 > 2:', 1.0 > 2)
print('1.0 <= 2:', 1.0 <= 2)
print('1.0 == 1:', 1.0 == 1)
print('1 != 1.0:', 1 != 1.0)

# Los operadores de igualdad y desigualdad los puedes usar en cadenas de texto:
print("'hola' == 'HOLA':", 'hola' == 'HOLA')
print("1.00 == '1.00':", 1.00 == '1.00')
print("'México' != 'Mexico':", 'México' != 'Mexico')
print("2 != 'Dos':", 2 != 'Dos')
