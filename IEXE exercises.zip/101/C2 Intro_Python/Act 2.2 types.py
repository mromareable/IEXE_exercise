# --------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# --------------------------------------------------------------------------------

# Ahora juguemos con tipos y operadores.

# Un tipo se refiere a la naturaleza de un valor o variable. Por ejemplo 3 es un
# número entero (int), 3.14159 es un número decimal (double) y 'Lunes' es una
# cadena de texto. 

# Existen muchos tipos, incluso puedes definir o crear un tipo nuevo. Por ahora
# vamos a experimentar con los tipos básicos.

# Un entero o int es un número que no tiene parte decimal. La función int() nos
# ayuda a convertir algo que no es un entero a un número entero:

# Descomenta las siguientes líneas y ve lo que sucede 
print(3)
print(int(3)) 

# Se imprime el número tres. La función int convierte el número entero 3 al mismo 
# número entero. No hace nada, pero tampoco afeca.

# Descomenta las siguientes líneas:
print('3')
print(int('3'))
print(int(3.0))

# Puedes ver que se imprime tres veces el número 3, pero no son iguales:
# El primer print imprime la cadena de texto '3', que es diferente al valor
# numérico tres. La función int('3') De igual forma la función int(3.0) convierte 
# el número decimal 3.0 al número entero 3.

# A los números con parte decimal se les llama "flotante" o "doble", debido a la 
# forma en la computadora representa la parte entera y la parte decimal.
# La función float() es similar a int(): convierte el argumento a un número 
# flotante.

# Descomenta las siguientes líneas y ejecuta el programa.
print(3.0)
print('3.0')
print(float('3.0'))
print(float(3.0))

# El tipo Booleano sólo puede contener dos valores: verdadero (True) y falso 
# (False). nota que la primera letra es mayúscula. 
# La función bool() convierte el argumento a un valor Booleano.

# Descomenta las siguientes líneas y ejecuta el programa.
print('True')
print(True)
print(bool('True'))
print(bool(True))

# Por último, el tipo de las cadenas de texto se llama string (str). Por ejemplo
# 'Lunes', 'pi', '3.14159'. Cualquier valor se puede representar mediante una 
# cadena de texto. La función str() convierte cualquier valor a su representación
# en cadena de texto.

# Descomenta las siguientes líneas y ejecuta el programa.
print('Lunes')
print('3.1415')
print(str(False))
print(str(3.0))

# Las cadenas de texto pueden estar rodeadas de comillas simples (') o comillas
# dobles ("). Siempre y cuando comiencen y terminen con el mismo tipo de comilla.
# Si inicias una cadena con comilla doble, el intérprete de Python va considerar
# todos los caractéres a la derecha como parte de la cadena hasta que encuentre
# otra comilla doble:

print("La suma es: 4+5")

# Lo mismo sucede con las comillas simples:
print('La suma es: 2+3')

# Esto es útil cuando quieres incluir comillas en la cadena de texto:

print('Nombre: "Chevrolet"')
print("Stacy's")

# Si quieres incluir una comilla del mismo tipo que define la candena de texto
# puedes usar la diagonal invertida (\) para indicar al intérprete de Python
# que no se está cerrando la cadena:

print('Esta cadena tiene una comilla simple (\')')
print("Esta cadena tiene una comilla doble (\")")

# Puedes crear cadenas con saltos de línea. Para esto es necesario indicarle al
# intérprete de Python que la cadena es multilínea usando tres comillas dobles
# o simples:

print('''
Esta es una cadena 
con 
múltiples líneas
''')

# Puedes usar múltiples valores en la instrucción print, separados por comas (,)
print('hola', 'adios')
print('la suma de 2+3=', 2+3)
print(2+3, '=5')
print('2+3=', 2+3, '(cinco)')
