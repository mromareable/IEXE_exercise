# # ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# --------------------------------------------------------------------------------

# Ahora ahora veamos cómo usar los operadores con los distintos tipos.

# Los operadores aritméticos como suma, resta, multiplicación y división funcionan
# igual que como aprendimos en primaria. Todos los operadores aritméticos 
# funcionan en valores de tipos enteros y de punto floante.

# Descomenta las siguientes líneas y ve lo que sucede:
print('2 + 4:', 2 + 4)
print('0 - 5.5:', 0 - 5.5)
print('2 * 3.05:', 2 * 3.05)
print('9 / -3:', 9 / -3)

# Puedes usar múltiples valores y múltiples operadores en la misma sentencia:
print('2 + 4 - 1 + 12 - 7:', 2 + 4 - 1 + 12 - 7)
print('2 * 3.05 / 5 * 8 / 4.5:', 2 * 3.05 / 5 * 8 / 4.5)

# El operador exponente se expresa con dos asteriscos juntos: **
print('2 ** 10:', 2 ** 10)
print('10 ** 2:', 10 ** 2)
print('81 ** 0.5:', 81 ** 0.5)

# Al símbolo de porcentaje se le llama operador módulo, y devuelve el residuo
# de la división entre los dos valores
print('10 % 3:', 10 % 3)
print('19 % 2:', 19 % 2)
print('2020 % 8:', 2020 % 8)
print('1000 % 5:', 1000 % 5)
print('5 % 1000:', 5 % 1000)

# El orden de los operadores es importante. Descomenta las siguientes lineas
# y ejecuta el programa
print('2 * 4 - 3 / 6 + 8 - 2 ** 3:', 2 * 4 - 3 / 6 + 8 - 2 ** 3)
print('2 * 4 - 3 / 6 + (8 - 2) ** 3:', 2 * 4 - 3 / 6 + (8 - 2) ** 3)
print('2 * 4 - 3 / (6 + 8) - 2 ** 3:', 2 * 4 - 3 / (6 + 8) - 2 ** 3)
print('2 * (4 - 3) / 6 + 8 - 2 ** 3:', 2 * (4 - 3) / 6 + 8 - 2 ** 3)
print('2 * 4 - 3 / (6 + (8 - 2)) ** 3:', 2 * 4 - 3 / (6 + (8 - 2)) ** 3)
print('2 * 4 - (3 / (6 + (8 - 2))) ** 3:', 2 * 4 - (3 / (6 + (8 - 2))) ** 3)
print('2 * (4 - (3 / (6 + (8 - 2)))) ** 3:', 2 * (4 - (3 / (6 + (8 - 2)))) ** 3)

# El tipo string o cadena soporta algunos operadores aritméticos:
print("'hola ' * 2:", 'hola ' * 2)
print("'ABC' * 10:", 'ABC' * 10)
print("'hola' + ' ' + 'adios':", 'hola' + ' ' + 'adios')
print("'hola' + (' ' * 5) + 'adios':", 'hola' + (' ' * 5) + 'adios')

# Pero no todos los operadores aritméticos funcionan con las cadenas. Descomenta
# las siguientes líneas y ejecutalas una por una.
print('hola' - 'o')
print('hola' / 3)
print(5 + 'adios')
print('100' / '10')


