# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Puede ser muy frustrante cuando comienzas a aprender un lenjuaje de programación,
# no sabes bien qué hacer ni qué mover para hacer lo que quieres.

# No te preocupes. Es normal y le pasó hasta a los mejores programadores. Como
# todo, con la práctica constante irás perdiendo el "miedo" y desarrollarás la
# intuición necesaria para programar.

# Python es un lenguaje interpretado, lo que significa que no vas a ver errores
# de compilación. Los errores los vas a ver hasta que ejecutes el programa.
# Quita el comentario de la siguiente línea y ejecuta el programa:
'a' = 4

# El intérprete arroja el siguiente error:
#   File "errors.py", line 15
# SyntaxError: cannot assign to literal

# Indica que no puede hacer una asignación a un valor literal. Específicamente
# se refiere a que no puede asignar el valor de 4 a una cadena de texto 'a'.
# ¿Qué debes hacer para corregir el error?

# ------------------------------------------------------------------------------
# El formato de un error es generalmente el mismo:
#   Lugar donde ocurre el error, número de línea
# Nombre del error: Descripción del error

# En programas más grandes hay mútiples mensajes del lugar donde ocurre el error, 
# estos lugares son los archivos con el código fuente con las últimas llamadas 
# a la línea de código que causó el error. Pero la última línea es siempre el
# nombre del error: Descripción del error

# Sería imposible listar todos los errores que existen en Python, ya que hay
# una infindad de errores, cada librería define nuevos errores e incluso tu 
# puedes definir tus propios errores.

# Cuando hagas un programa y tengas un error lo primero que debes de hacer ver
# el mensaje del error. Quita el comentario y ejecuta la siguiente línea de
# código:

print(nombre)

# Ups. Hubo un error, identifica el mensaje. Es el que dice 
# "NameError: name 'nombre' is not defined"
# NameError es la clase del error y nos dice que es un error de nombres o de
# identificadores. Lo que sigue es un mensaje más descriptivo del error:
# name 'nombre' is not defined" nos dice que el identificador "name" no ha
# sido definido. En otras palabras, la variable "nombre" no se ha declarado.

# Descomenta las siguientes líneas y ejecuta el programa
name = 'Pedro'
print('hola' name)

# Ahora el error es el siguiente:
#   File "errors.py", line 53
#     print('hola' name)
#                  ^
# SyntaxError: invalid syntax

# Ahora la descripción del error dice "SyntaxError: invalid syntax". Este error 
# es un poco más difícil de entender. SyntaxError nos dice que es un error en la 
# forma en la que está escrito el programa. El mensaje "invalid syntax" realmente 
# no dice mucho más, pero en este caso nota el pequeño acento circunflejo (^) 
# que está bajo la "n" de la variable "name". Este acento es una pista que el 
# intérprete de Python nos brinda para identificar el lugar donde está el error 
# de sintáxis. Nota que está debajo de la variable "name". Ese fue el lugar donde 
# Python no supo cómo ejecutar el programa.

# ¿qué es lo que hace falta para que el pograma funcione correctamente?
# Realiza el cambio necesario
name = 'Pedro'
print('hola', name)

# Ahora descomenta la siguiente línea y ejecuta el programa:
cinco = int('10') / 2
print(cinco)

# El error es un poco más descriptivo: 
#   File "errors.py", line 78, in <module>
#     cinco = '10' / 2
# TypeError: unsupported operand type(s) for /: 'str' and 'int'

# En la práctica de tipos ya habíamos visto este mensaje, pero no lo analizamos
# con detalle. TypeError nos dice que es un error de tipos. Y el mensaje del
# error nos dice que el operador división (/) no se puede aplicar en los tipos
# str o cadena, y el tipo int o entero.
# ¿qué es necesario para que el programa funcione correctamente?

# ------------------------------------------------------------------------------
# Cuando programes te vas a enfrentar con múltiples errores y situaciones
# inesperadas. El programa no va a funcionar hasta que el intérprete sepa bien
# qué hacer con las instrucciones que le das mediante líneas de código. 
# Cuando tengas un error es necesario que conserves la calma y no te frustres
# seguramente la solución es más fácil de lo que te imaginas. Lee con calma
# el mensaje del error e intenta averiguar por qué el intérprete no pudo 
# ejecutar el programa. ¿Qué fueron los cambios que hiciste desde la última vez
# que funcionaba el programa? ¿Qué variables estás usando? ¿de qué tipo son?

# Si no encuentras el motivo del error, existen muchos sitios en línea o
# foros en internet que te pueden ayudar a encontrar el error. Un buen punto de
# partida es copiar el mensaje del error y buscarlo en Google. Lo más seguro
# es que encuentres una explicación o por lo menos una pista a lo que puede
# estar causando el problema.
