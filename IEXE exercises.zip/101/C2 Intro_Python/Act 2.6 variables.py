# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Las variables son referencias a un valor que podemos usar en múltiples
# partes del código. Para usarlas simplemente usa el nombre de la variable,
# seguida del operador de asignación (=) y el valor de la variable:

dia = 'Lunes'
edad = 20
peso = 48.62

# Descomenta la siguiente línea y ejecuta el programa.
print('dia:', dia, 'edad:', edad, 'peso:', peso)

# En Python no hay diferencia entre inicializar una variable y asignarle un valor.
# Python la inicializa automáticamente si usas un nombre de variable que no existe, 
# si ya existe entonces reemplaza el valor:

dia = 'Martes'
peso = 50.5

# Descomenta la siguiente línea y ejecuta el programa.
print('dia:', dia, 'edad:', edad, 'peso:', peso)

# El intérprete de Python infiere el tipo de las variables:
print('el tipo de la variable "dia" es', type(dia))
print('el tipo de la variable "edad" es', type(edad))
print('el tipo de la variable "peso" es', type(peso))

# <class 'str'> o <class 'int'> se refiere a que el tipo es una clase de nombre
# "str" o "int". Por ahora no te preocupes por saber qué es una clase. 

# El tipo de una variable puede cambiar en cualquier momento:
dia = 1
edad = 23.5
peso = '49'

# Descomenta la siguiente línea y ejecuta el programa.
print('el tipo de la variable "dia" es', type(dia))
print('el tipo de la variable "edad" es', type(edad))
print('el tipo de la variable "peso" es', type(peso))

# Puedes inicializar más de una variable en una línea:
dia, edad, peso = 'Martes', 30, 65.4
print('dia:', dia, 'edad:', edad, 'peso:', peso)

# ------------------------------------------------------------------------------
# El número de variables que declaras a la izquierda del operador de igualdad
# debe de coincidir con el número de valores que se encuentran de lado
# derecho del igual. 
# La siguiente línea provoca un error en el programa, quita el comentario y
# ejecuta el programa. ¿qué dice el error?

anio, mes, dia = 2000, 4, 24
# ahora agrega una variable 'dia' para que funcione.

# Nota que los nombres de las variables no van entre comillas, de otra forma
# se convierten en una cadena de texto.
# Ejecuta la siguiente línea de código y lee con cuidado el error
saldo = 3000.5

# Ahora haz lo necesario para que el programa funcione correctamente.
print(saldo)