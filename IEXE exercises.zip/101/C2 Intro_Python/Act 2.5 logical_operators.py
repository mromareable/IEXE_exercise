# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Los operadores lógicos evalúan dos valores booleanos. Funcionan también de una
# forma intiutiva. Son los operadores and, or y not. (y, o, no). 

# Descomenta las siguientes líneas y ve con detalle los resultados:
print('True and True:', True and True)
print('False and True:', False and True)
print('True or True:', True or True)
print('False or True:', False or True)
print('not False:', not False)
print('not True:', not True)

# Puedes combinar estos operadores con cualquier otro tipo de operador que
# evalúe un valor booleano:
print('1 < 2 and 2 < 3:', 1 < 2 and 2 < 3)
print('1 > 2 and 1 < 3:', 1 > 2 and 1 < 3)
print('1 < 2 or 1 < 3:', 1 < 2 or 1 < 3)
print('1 > 2 or 1 < 3:', 1 > 2 or 1 < 3)
print('1 < 2 and not 2 < 3:', 1 < 2 and not 2 < 3)
print('1 < 2 or not 2 < 3:', 1 < 2 or not 2 < 3)
print('1 > 2 and not 2 < 3:', 1 > 2 and not 2 < 3)
print('1 < 2 or not 2 < 3:', 1 < 2 or not 2 < 3)

# También funcionan con valores numéricos. Cualquier número diferente de cero
# equivale a True, y cero equivale a False. No es recomendable usarlos ya
# que no es claro el comportamiento de este operador con valores numéricos
print('0 and 4:', 0 and 4)
print('0 or 4:', 0 or 4)
print('not 0:', not 0)

