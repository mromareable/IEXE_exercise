# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Calcula el perímetro, área y volumen de un círculo o esfera en el caso del
# volumen.

# Para este problema, define la constante PI como 3.14159
PI = 3.14159

# Las fórmulas son:
# perímetro = 2 * PI * radio
# área = PI * (radio * radio)
# volumen = (4/3)* PI * (radio * radio * radio)


# La única variable que necesitas del usuario es el radio. Modifica la siguiente
# línea para capturar el radio en una variable de tipo flotante
radio = float(input())

# ahora calcula los 3 valores requeridos no uses acentos ni caracteres especiales
# en los nombres de las variables.
perimetro = 2 * PI * radio
area = PI * (radio * radio)
volumen =  (4/3)* PI * (radio * radio * radio)

# Despliega el resultado de los 3 valores:
print('perimetro =', perimetro)
print('area =', area)
print('volumen =', volumen)

# Prueba tu programa varias veces. Luego presiona el botón de "evaluar" para 
# calificar tu programa.

