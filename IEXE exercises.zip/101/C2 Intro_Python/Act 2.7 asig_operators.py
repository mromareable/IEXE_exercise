# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# En la prácica pasada usamos el operador de asignación (=) para asignar un
# valor a una variable. 
saldo = 300.5
print('El saldo es:', saldo)

# Recuerda que el operador de asignación es sólo un símbolo igual. El operador
# comparación son dos símbolos de igual juntos (==), y evalúa si los valores
# que están a los lados son iguales.

# Descomenta la siguiente línea y modifícala para que imprima "True"
print(saldo == 0)

# Existen múltiples operadores además del operador de asignación. Existe un
# operador de asignación para cada uno de los operadores aritméticos:
saldo += 100

# Descomenta la siguiente línea. ¿qué sucedió al valor del saldo?
print('El saldo es:', saldo)

# El operador += toma el contenido de la variable y suma el valor que se 
# encuentra a la derecha. Las siguientes dos líneas suman 10 a la variable
# saldo:
saldo = saldo + 10
print('El saldo es:', saldo)
saldo += 10
print('El saldo es:', saldo)

# Al igual que el operador +=, existe el operador -=. Este operador resta al 
# valor actual de la variable de lado izquierdo el valor de lado derecho:
saldo -= 200
print('El saldo es:', saldo)

# Intuitivamente existen los operadores *=, /=.
# Escribe una instrucción que multiplique el saldo por 10:
saldo *= 10
print('El saldo es:', saldo)

# Anora escribe una instrucción que divida el saldo entre 4:
saldo /= 4
print('El saldo es:', saldo)

# ¿qué crees que hace el operador **=?

# ------------------------------------------------------------------------------
# Existen otros operadores que vamos a conocer a lo largo de la clase. Por ahora
# ya conoces los operadores básicos para hacer programas interesantes.
