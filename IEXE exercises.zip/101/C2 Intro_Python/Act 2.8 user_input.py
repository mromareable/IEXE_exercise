# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Ahora hagamos una actividad simple.

# Usa la función input() para solicitar una entrada del usuario. Descomenta la
# siguiente línea y ejecuta el programa.
input('¿Cuál es tu nombre? ')

# El sistema le pide al usuario -en este caso tu- su nombre. Pero no hay ninugna
# variable que guarde el valor del nombre del usuario. Descomenta la siguiente
# línea y ejecuta el programa:
nombre = input('¿Cuál es tu nombre? ')

# Ahora tenemos una variable nombre que almacena el nombre del usuario, pero
# no sucede nada. Agrega lo necesario a la siguiente línea para que se imprima
# el nombre del usuario.
print('Mucho gusto', nombre)

# Ahora que conoces el nombre del usuario, invítalo a calcular el área de un
# rectángulo. La fórmula es area = base * altura

# print('')

# Primero pide el valor de la base:
base = input('¿cuál es la base? ')

# luego pide el valor de la altura:
altura = input('¿cuál es la altura? ')

# El área es la multiplicación de estos valores. Descomenta la línea y
# ejecuta el programa
# area = base * altura

# Ups. Hubo un error. El mensaje de error dice algo como:
# "TypeError: can't multiply sequence by non-int of type 'str'"
# El error se debe a que estás intentando multiplicar dos cadenas de texto,
# y Python no sabe cómo hacer eso. Esto se debe a que la función input()
# devuelve una cadena de texto, por lo que es necesario convertir la cadena
# de texto a un valor numérico usando la función int()
base_numerica = int(base)
altura_numercia = int(altura)

# Ya que tienes las variables de tipo numérico puedes calcular la base:
area = base_numerica * altura_numercia

# ahora despliega al usuario el valor del área del rectángulo:
print('Area del rectangulo: ', area)

# Listo! Ya sabes pedir entradas del usuario y usarlas como variables.

# Como vimos en la práctica anterior, no es necesario crear nuevas variables,
# basta con volver a asignar un valor, ahora de tipo numérico:
base = int(base)
altura = int(altura)
area = base * altura
print('El área del rectángulo de', nombre, 'es', area)

