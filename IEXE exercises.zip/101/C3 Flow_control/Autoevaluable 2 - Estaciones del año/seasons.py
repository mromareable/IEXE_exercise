# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------
import datetime
# Captura el año, mes y dia del usuario:
anio = int(input('Ingresa el año: '))
mes = int(input('Ingresa el mes: '))
dia = int(input('Ingresa el dia: '))
# if mes==3 and 1<=dia<=15:
#     print('primera mitad del mes')
# elif mes==3 and 16<=dia<=31:
#     print('segunda mitad del mes')
# # Validación simple del año, mes y dia
if anio <= 0 or mes <= 0 or dia <= 0:
    print('Fecha Invalida')
else:
    if mes > 12:
        print('Fecha Invalida')
    else:
        # Termina el programa aqui.
        # Primero revisa si el año sea bisiesto. Si el año es bisiesto 
        # entonces el 29 de febrero es una fecha válida. 
        # Posteriormente usa sentencias if-else para determinar la
        # estación del año correspondiente.
        if (anio % 4 ==0 and (anio % 100 != 0 or anio % 400 == 0)):
            print("Año bisiesto")
        else:
            if 3<=mes<=6:
                if mes==3 and 20<=dia<31:
                    print('Primavera')
                elif mes==6 and 1<=dia<20:
                    print('Primavera')
                else:
                    print('Primavera')
            elif 6<=mes<=9 :
                if mes==6 and 20<=dia<30:
                    print('Verano')
                elif mes==9 and 1<=dia<=21:
                    print('Verano')
                else:
                    print('Verano')
            elif 9<=mes<=12 :
                if mes==9 and 22<=dia<30:
                    print('Otoño')
                elif mes==12 and 1<=dia<21:
                    print('Otoño')
                else:
                    print('Otoño')
            elif mes==12 or 1<=mes<=3:
                if mes==12 and 21<=dia<31:
                    print('Invierno')
                elif mes==3 and 1<=dia<20:
                    print('Invierno')
                else:
                    print('Invierno')

# Tu programa debe pedirle al usuario tres números enteros:

# año a cuatro dígitos
# mes a uno o dos dígitos
# día a uno o dos dígitos
# Y tu programa debe escribir el nombre de la estación del año:

# "Primavera" si es mayor o igual al 20 de marzo y menor al 20 de junio
# "Verano" si es mayor o igual al 20 de junio y menor al 22 de septiembre
# "Otoño" si es mayor o igual al 22 de septiembre y menor al 21 de diciembre
# "Invierno" si es mayor o igual al 21 de diciembre y menor al 20 de marzo