# ------------------------------------------------------------------------------
# =================== Programación para Ciencia de Datos =======================
# ------------------------------------------------------------------------------

# Solucion a la actividad de Estaciones del Año.
# Nota: Existen cientos de formas distintas de resolver este problema, esta es
#       sólo una de ellas. Algunas pueden tener más código y otras menos código

# Primero solicitamos al usuario la fecha. Nota que no usamos nada en la
# función input para que los mensajes no interfieran con la evaluación automática
anio = int(input())  # Recuerda que la función input() devuelve una cadena de
mes = int(input())   # texto, por lo que hay que convertirla a un valor 
dia = int(input())   # numérico mediante la función int()

# Lo primero que hacemos es validar que los tres valores sean positivos, y en
# en el caso del día no puede ser mayor a 31 y el caso del mes no puede ser
# mayor a 12
if anio <= 0 or mes <= 0 or dia <= 0 or mes > 12 or dia > 31:
    print('Fecha Invalida')
else:  # Primero revisamos si el año es bisiesto.
    bisiesto = False                # ¿se te ocurre una forma mejor de
    if anio % 4 == 0:               # expresar estas sentencias if anidadas?
        bisiesto = True
        if anio % 100 == 0:
            bisiesto = False
            if anio % 400 == 0:
                bisiesto = True
    # Ya que sabemos si el año es bisiesto, validamos el mes y el día
    if bisiesto and mes == 2 and dia > 29:
        print('Fecha Invalida')
    elif not bisiesto and mes == 2 and dia > 28:
        print('Fecha Invalida')
    # Validamos los meses que tienen 30 días
    if mes in (4, 6, 9, 11) and dia == 31:
        print('Fecha Invalida')
    # En este punto ya sabemos que la fecha es válida, sólo queda ver la
    else:   # estación del año a la que pertenece la fecha. Primero imprimimos
        if mes in (1, 2):  # la estacion del año para los meses que no tienen
            print('Invierno')  # cambio de estacion
        elif mes in (4, 5):
            print('Primavera')
        elif mes in (7, 8):
            print('Verano')
        elif mes in (10, 11):
            print('Otono')
        else:  # Para los meses que tienen transición de estación, verificamos
            if mes == 3:  # el día del mes y con él indicamos la estación
                if dia < 20:  # a la que pertenecen.
                    print('Invierno')
                else:
                    print('Primavera')
            if mes == 6:
                if dia < 20:
                    print('Primavera')
                else:
                    print('Verano')
            if mes == 9:
                if dia < 22:
                    print('Verano')
                else:
                    print('Otono')
            if mes == 12:
                if dia < 21:
                    print('Otono')
                else:
                    print('Invierno')

# Esta es sólo una solución posible. Hay formas más claras de verificar la 
# estación del año. ¿te se ocurre una mejor?
