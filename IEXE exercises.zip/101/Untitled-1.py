def mi_funcion(x, *y,**z):
    print(x, y, z)

mi_funcion(a='b', y=10, x=20, z=30)