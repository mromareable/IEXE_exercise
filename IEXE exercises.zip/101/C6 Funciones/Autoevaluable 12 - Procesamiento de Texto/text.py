# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Escribe una función que analice una cadena de texto. La función debe contar
# las palabras contenidas en el texto y devolverlo como un diccionario, por 
# ejemplo: la cadena de texto "una computadora gris y una mesa gris" debe devolver
# el siguiente diccionario:
# {
#     "una": 2,
#     "computadora": 1,
#     "gris": 2,
#     "mesa": 1,
#     "y": 1
# }
# 
# Ya que las palabras "una" y "gris" se repiten dos veces, mientras que las  
# demás palabras aparecen sólo una vez. Si la cadena está vacía se devuelve un
# diccionario vacío.
#
# La función debe convertir todo el texto a minúsculas, de tal forma que las
# palabras "lapiz" y "LAPIZ" son la misma palabra.
# 
# La función también puede recibir argumentos nombrados opcionales donde cada 
# uno es una variable de tipo booleana que indica:
#   - Si la variable es True entonces ese valor se va a agrupar en "GRUPO"
#   - si la variable es False entonces ese valor se va a omitir en el conteo
# de palabras. Por ejemplo: la cadena de texto "una computadora gris y UNA MESA ROJA"
# y los argumentos nombrados y=False, gris=True, roja=True debe devolver el
# diccionario:
# {
#     "una": 2,
#     "computadora": 1,
#     "mesa": 1,
#     "GRUPO": 2
# }
# En este ejemplo, la palabra "y" se omitió de la salida, ya que el argumento
# nombrado y=False indica que se debe omitir del análisis. Además la palabra
# "GRUPO" contiene el número de palabras donde el argumento opcional tiene el
# valor de True, en este caso gris=True y roja=True.
#
# Por ejemplo, la cadena de texto "el perro y el gato viejo entraron en el cuarto viejo y oscuro"
# con los argumentos y=False, perro=True, gato=True, la salida debe ser el 
# diccionario:
# {
#     'el': 3, 
#     'GRUPO': 2, 
#     'viejo': 2, 
#     'entraron': 1, 
#     'en': 1, 
#     'cuarto': 1, 
#     'oscuro': 1
# }
#
# Tips: 
#    - Usa diccionarios para llevar el conteo de cada palabra
#    - Usa el método split() para separar el texto en palabras
#    - Usa argumentos nombrados opcionales
def procesa_texto(txt, **op_arg):
    cnt_w = {}
    for wd in txt.lower().split(' '):
        if wd in op_arg:
            if op_arg.get(wd):
                wd = 'GRUPO'
            else:
                continue
        if wd in cnt_w:
            cnt_w[wd] += 1
        else:
            cnt_w[wd] = 1
    return cnt_w


if __name__ == "__main__":
    print(procesa_texto('"una computadora gris y UNA MESA ROJA"'))
