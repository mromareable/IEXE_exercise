# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------
import math
# Escribe una función que resuelva la fórmula cuadrática o la ecuación cuadrática 
# (https://en.wikipedia.org/wiki/Quadratic_formula).

# La función se debe de llamar "cuadratica" y recibe como argumento los valores 
# a, b y c. Y devuelve una lista con las dos raices reales de la ecuación 
# definida por a(x*x) + bx + c = 0.

# El número de soluciones está definido por el discriminante, que es el la parte
# de la ecuación que se expresa dentro de la raíz cuadrada.
#   1) Si el discriminante es menor a cero, entonces la ecuación no tiene 
#      solución real.
#   2) Si el discriminante es igual a cero, entonces existe sólo una solución
#      real.
#   3) Si el discriminante es mayor a cero, entonces existen dos soluciones
#      reales.
# 
# Para el caso 1. La función debe devolver None. Por ejemplo:
#    cuadratica(3, 2, 1) = None
# Para el caso 2. La función debe devolver una lista con dos valores iguales
#    cuadratica(1, 2, 1) = [-1.0, -1.0]
# Para el caso 3. La función debe devolver una lista con dos valores diferentes
#    cuadratica(1, -5, 2) = [0.4384471871911697, 4.561552812808831] 
def cuadratica(a, b, c):
    list_values = []
    r = (b**2)-(4*a*c)
    if r >= 0:
        sr = math.sqrt(r)
        xf = ((-1*b)-sr)/(2*a)
        xs = ((-1*b)+sr)/(2*a)
        list_values.append(xf)
        list_values.append(xs)
        return list_values
    else:
        return None
        
if __name__ == "__main__":
    fv = int(input())
    sv = int(input())
    tv = int(input())
    print(cuadratica(fv, sv, tv))