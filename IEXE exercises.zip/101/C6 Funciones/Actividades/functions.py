# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Como viste en clase, las funciones son fragmentos de código "empaquetados", 
# de tal forma que puedes ejecutar el mismo código múltiples veces. 

# La sintáxis de una función es la palabra reservada "def", seguida del nombre
# de la función y entre paréntesis los argumentos que recibe.

def imprime_numero(numero):
    print('el número es: {}'.format(numero))

for i in range(10):
   imprime_numero(i)

# ------------------------------------------------------------------------------
# Las funciones devuelven un valor mediante la palabra reservada "return":

def raiz_cuadrada(numero):
    return numero ** 0.5

for i in range(10, 100, 10):
   raiz = raiz_cuadrada(i)
   print('La raiz cuadrada de {} es {}'.format(i, raiz))

# ------------------------------------------------------------------------------
# En python, si una función no devuelve nada explícitamente mediante la palabra
# "return", el valor por defecto que se usa como valor de retorno es None. 

x = imprime_numero(100)
print('El valor devuelto por la función imprime_numero es {}'.format(x))

# ------------------------------------------------------------------------------
# Las funciones son muy útiles para realizar tareas repetitivas, transformando
# los argumentos y devolviendo un valor que depende de ellos:

def sumatoria(lista):
    suma = 0
    for valor in lista:
        suma = suma + valor
    return suma

print('La suma es: {}'.format(sumatoria([10, 45, 92, 7, 51, 28, 24, 61, 55, 2])))

# ------------------------------------------------------------------------------
# Las funciones pueden recibir más de un argumento o parámetro:

def calcula_interes_anual(monto, tasa, meses):
    return monto * (1 + (tasa / 12)) ** meses

inicial = 100
tasa_interes = 0.3 # 30%
plazo = 48

total = calcula_interes_anual(inicial, tasa_interes, plazo)
print('El total a pagar es de {}'.format(total))
