# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Cuando usas un argumento en una función, este argumento existe sólo durante la
# ejecución de la función:

def mi_funcion():
    numero = 24
    print('número = {}'.format(numero))

mi_funcion()

# La siguiente línea produce un error por que la variable número no existe
# fuera de mi_funcion:
print('número = {}'.format(numero))

# ------------------------------------------------------------------------------
# Incluso si la variable existe antes de que se ejecute el método, las variables
# dentro de una función sólo viven durante la ejecución de la misma:

fecha = '18 de diciembre de 2000'

def mi_funcion(fecha):
    print('en mi_funcion, la fecha es {}'.format(fecha))

mi_funcion(24)

print('Fuera de mi_funcion, la fecha es {}'.format(fecha))

# ------------------------------------------------------------------------------
# Si una función cambia el valor de una variable, el nuevo valor sólo vive mientras
# se ejecuta la función. A esto se le llama "paso de argumentos por VALOR"

def mi_funcion(x, y):
    x = 1 / y
    y = x * 3.14159
    print('En mi_funcion, x = {}, y = {}'.format(x, y))

x = 10
y = 20
print('Antes de llamar a mi_funcion, x = {}, y = {}'.format(x, y))
mi_funcion(x, y)
print('Después de llamar a mi_funcion, x = {}, y = {}'.format(x, y))

# ------------------------------------------------------------------------------
# Puedes indicar el valor de los argumentos si usas su nombre durante la
# llamada de la función:

def calcula_pendiente(x1, x2, y1, y2):
    return (y2-y1) / (x2-x1)

pendiente1 = calcula_pendiente(5, 6, 2, 10)
print('pendiente1 = {}'.format(pendiente1))

pendiente2 = calcula_pendiente(y2=5, y1=6, x2=2, x1=10)
print('pendiente2 = {}'.format(pendiente2))

# # No es necesario que nombres todos los argumentos, el orden en el que están
# # definidos en el método es el órden en el que se consideran:
pendiente3 = calcula_pendiente(4, 0, y2=10, y1=2)
print('pendiente3 = {}'.format(pendiente3))

# # Pero ten cuidado, si usas nombres de argumentos que ya se usaron por defecto
# # tendrás un error en el programa:
pendiente4 = calcula_pendiente(4, 0, x1=10, y1=2)
print('pendiente4 = {}'.format(pendiente4))

# ¿por qué sucede el error en la línea anterior?
# Al momento de llamar calcula_pendiente por el orden de los argumentos por default el interprete 
# entiende que se le esta asigando 4 a x1 para luego despues asignarlo un segundo valor (10).
# Por lo que se genera el error de asignación multiple