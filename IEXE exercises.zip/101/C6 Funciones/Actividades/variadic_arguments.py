# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Los argumentos son aún más flexibles. Puedes declarar una función que recibe
# un número ilimitado de argumentos al nombrar un argumento con el símbolo *
# antecediendo al nombre de la variable. El intérprete de Python empaqueta todos
# los argumentos adicionales en una tupla, que puedes usar a través de esta
# variable:

def suma(*numeros):
    total = 0
    for x in numeros:
        total += x
    return total

print('suma: {}'.format(suma(10, 2, 4, 8)))
print('suma: {}'.format(suma()))
print('suma: {}'.format(suma(0, -1, -2, -3, -4, -5, -6, -7, -8, -9)))

# Estos argumentos los puedes combinar con argumentos normales y con argumentos
# nombrados:

def funcion(x, y, *opciones):
    print('x = {}, y = {}, opciones = {}'.format(x, y, opciones))

funcion(10, 'Rojo', True, False, False, True, False, False, False, True)
funcion(-5, 'Azul')

# Sin embargo, estos argumentos no los puedes combinar con argumentos nombrados:
#funcion(x=0, y='Verde', 0, 1, 2, 3)
# ¿por qué crees que sucede este error?
# Debido a que en un Tupla, los valores tienen que ser del mismo tipo, en la var y se le asigna un valor string
# y el resto son valores enteros
# Además, no puedes usar más de un argumento variable por función:
#def imposible(*listaA, *listaB):
#    print('Ups')
# Reflexiona, si esto fuera posible, ¿dónde termina listaA y dónde comienza listaB?
# imposible(1, 2, 'A', False)
# lista A termina en 2 y lista B comienza en A
# ------------------------------------------------------------------------------
# Podemos hacer lo mismo con argumentos nombrados, pero las variables que reciben
# múltiples argumentos nombrados se requiere de dos asteriscos antes del nombre
# de la variable. Y esta variable es un diccionario donde las llaves son los
# nombres de los argumentos:

def registra_usuario(id_usuario, **datos):
    print('Registrando usuario con ID {}'.format(id_usuario))
    for nombre, valor in datos.items():
        print('  |- {}: {}'.format(nombre, valor))

registra_usuario(1, nombre='Gabriela', apellidos='Rojo', departamento='contabilidad')
registra_usuario(2, nombre='Rodrigo', apellidos='Puente', sueldo=1000)
registra_usuario(3, puesto='Director', fecha_ingreso='2015-06-15', sueldo=5000)

# ¿qué pasa si no indicas el argumento id_usuario?
# el interprete encuentra un error indicando que falta un argumento obligatorio para el funcionmiento de la función
# Es muy común encontrar en bibliotecas de python métodos definidos de la 
# siguiente forma:
def funcion_especial(*args, **kwargs):
    print('Argumentos posicionales: {}'.format(args))
    print('Argumentos nombrados: {}'.format(kwargs))

# De esta forma la función puede recibir cualquier cantidad y tipo de argumentos:
funcion_especial()
funcion_especial(cuatro=4, z='zeta')
funcion_especial(10, 100, 0)
funcion_especial(0, debug=False)

# Así puedes crear funciones sumamente flexibles. Depende de la implementación
# de la función procesar todos los argumentos tanto posicionales como nombrados.
