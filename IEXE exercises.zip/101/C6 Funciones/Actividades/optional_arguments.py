# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Los argumentos opcionales son útiles cuando una función puede asumir el valor
# de un argumento por defecto, a menos de que explícitamente se indique cuando
# se llama a la función:

def saludo(nombre, mensaje='Hola'):
    print('{} {}!'.format(mensaje, nombre))

saludo('María')
saludo('Mario', 'Buenas tardes')

# Puedes usar nombres en los argumentos como cualquier otra función:
saludo(mensaje='Hasta luego', nombre='Juan')

# ------------------------------------------------------------------------------
# Son también útiles para modificar el comportamiento de una función:
def convierte_metros(cantidad, unidad='pies'):
    if unidad == 'pies':
        return cantidad * 0.3048
    elif unidad == 'yardas':
        return cantidad * 0.9144
    elif unidad == 'pulgadas':
        return cantidad * 39.3701
    else:
        return None # unidad no encontrada

print('10 metros son {} pies'.format(convierte_metros(10)))
print('10 metros son {} yardas'.format(convierte_metros(10, unidad='yardas')))
print('10 metros son {} pulgadas'.format(convierte_metros(10, unidad='pulgadas')))

# ------------------------------------------------------------------------------
# Puedes usar más de un argumento opcional en las funciones:
def registra_usuario(nombre, apellidos, es_administrador=False, activo=True):
    if es_administrador:
        print('Registrando a {} {} como administrador'.format(nombre, apellidos))
    if not activo:
        print('{} {} no está activo en el sistema'.format(nombre, apellidos))


registra_usuario('Roberto', 'Pérez')
registra_usuario('Gina', 'López', True, False)
registra_usuario('Mónica', 'Sánchez', activo=True)

# ------------------------------------------------------------------------------
# Los argumentos opcionales siempre deben de ser los últimos en la definición
# del método. No pueden ir antes que los argumentos no opcionales:
def registra_usuario(es_administrador=False, activo=True, nombre, apellidos):
   if es_administrador:
       print('Registrando a {} {} como administrador'.format(nombre, apellidos))
   if not activo:
       print('{} {} no está activo en el sistema'.format(nombre, apellidos))
