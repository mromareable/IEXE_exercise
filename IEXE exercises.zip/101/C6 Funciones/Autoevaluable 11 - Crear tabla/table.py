# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Escribe una función que reciba como argumento un número ilimitado de listas,
# y devuelve una lista de listas con los arugmentos en forma tabular:
# Ejemplo 1:
#     argumento 1: [1, 2, 3, 4]
#     argumento 2: [4, 3, 2, 1]
#     salida: [[1, 4], [2, 3], [3, 2], [4, 1]]
#
# Ejemplo 2:
#     argumento 1: 'cinco' # recuerda que las cadenas de texto se consideran listas
#     argumento 2: [0, -1, -2, -3, -4]
#     argumento 3: '!.-?='
#     salida: [['c', 0, '!'], ['i', -1, '.'], ['n', -2, '-'], ['c', -3, '?'], ['o', -4, '=']]
#
# Nota que el el tamaño de listas internas es del número de argumentos que 
# recibe como parámetro. Y el número de listas es igual a la longitud de la
# lista con menos elementos:
# Ejemplo 3:
#     argumento 1: 'este es un ejemplo'
#     argumento 2: [100, 200, 300]
#     argumento 3: 'abcdefghijklmopqrstuvwxyz'
#     argumento 4: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.10]
#     salida: [['e', 100, 'a', 0.1], ['s', 200, 'b', 0.2], ['t', 300, 'c', 0.3]]
# En este ejemplo, el argumento 2 es la lista con menos elementos (3), por lo 
# que la lista de salida tiene tres elementos.
#
# tu función se debe de llamar "crea_tabla"
def crea_tabla(*dlist):
    if len(dlist) == 0:
        return []
    f_table = []
    t_elems = 1000001
    for i_list in dlist:
        if len(i_list) < t_elems:
            t_elems = len(i_list)
    for j in range(t_elems):
        p_list = []
        for k_list in dlist:
            p_list.append(k_list[j])
        f_table.append(p_list)
    return f_table
if __name__ == "__main__":
    print(crea_tabla([1, 2, 3, 4],[4, 3, 2, 1]))