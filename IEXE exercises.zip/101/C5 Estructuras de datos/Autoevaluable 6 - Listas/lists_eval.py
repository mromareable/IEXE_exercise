# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# En esta práctica vas a usar algunos métodos de las listas para manipular su
# contenido. Es importante que no elimines las sentencias print() para la 
# evaluacion automática.

# Escribe el código para agregar "equitación" a la tercera posición (es decir, 
# justo antes del voleibol) en la lista de deportes.
sports = ['cricket', 'football', 'volleyball', 'baseball', 'softball', 'track and field', 'curling', 'ping pong', 'hockey']
# Modifica aquí la lista
sports.insert(2,'equitación')
print(','.join(sports)) # No modifiques esta línea

# ------------------------------------------------------------------------------
# Escribe el código para sacar "Londres" de la lista de viajes.
viajes = ['Beirut', 'Milan', 'Pittsburgh', 'Buenos Aires', 'Nairobi', 'Kathmandu', 'Osaka', 'Londres', 'Melbourne']
# Modifica aquí la lista
viajes.remove('Londres')
print(','.join(viajes)) # No modifiques esta línea

# ------------------------------------------------------------------------------
# Para cada cadena en verbs, agregua "ed" al final de la palabra (para convertir 
# la palabra en pasado). Guarde estas palabras en tiempo pasado en una lista 
# llamada past_verbs.

verbs = ["end", 'work', "play", "start", "walk", "look", "open", "rain", "learn", "clean"]
# crea aquí la lista past_verbs
past_verbs = []
for i in verbs:
    past_verbs.append(i+'ed')
print(','.join(past_verbs)) # No modifiques esta línea

# ------------------------------------------------------------------------------
# Escribe el código necesario para unir las siguientes listas en una lista C.
A = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio']
B = ['Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
# Crea aquí la lista C y junta las listas A y B
C = A + B
print(','.join(C)) # No modifiques esta línea

# ------------------------------------------------------------------------------
# Utiliza la palabra reservada "del" para eliminar los elementos de la lista
# cuyos índices son pares:
lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Ojo! los índices de los elementos de la lista cambian despúes de cada
# ejecución de la palabra reservada "del"
# Elimina aquí los elementos con índice par.
for i in range(5):
    del lista[i]
print(','.join([str(c) for c in lista])) # No modifiques esta línea