# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Utiliza la biblioteca random para generar 1000 números aleatorios entre -1000
# y 1000. Posteriormente ordénalos de forma ascendente. Guarda la lista final en
# una variable llamada "ordenada".

# TIP: Para ordenar la lista necesitas dos ciclos. NO USES LA FUNCIÓN 
# sort() O sorted().

import random

ordenada = [] 
# Llena aquí la lista con 1000 elementos. Utiliza la función 
# random.randint(-1000, 1000) para generar los números aleatorios
for i in range(1,1001):
    ordenada.append(random.randint(-10,10))
print('Original')
print(ordenada)
# Escribe aquí el código necesario para ordenar la lista. Recuerda que no 
# puedes usar la función sort() o sorted().
# La evaluación automática espera una lista llamada "ordenada". No cambies el
# nombre de la variable. 
for i in range(0, len(ordenada)):
    for j in range(0, len(ordenada)):
            if ordenada[i] < ordenada[j]:
                tmp = ordenada[i]
                ordenada[i] = ordenada[j]
                ordenada[j] = tmp
print(ordenada)
