# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Las tuplas son una estructura de datos muy parecida a las listas. Son colecciones
# de valores ordenados, se distinguen de las listas por que son inmutables, es 
# decir, que no puedes modificar los elementos ni el tamaño de una tupla.

# Pareciera que esta estructura de datos no es de gran utlidad, ya tienen más
# restricciones que las listas. La ventaja es que ocupan mucha menos memoria que 
# una lista tradicional. Muchas librerías usan las tuplas para representar 
# argumentos o valores de retorno de las funciones.

# Crear una tupla es muy fácil:
tup1 = ('python', 2000)
tup2 = (1, 2, 3, 4, 5)
tup3 = "a", "b", "c", "d"

print('tup1: {}'.format(tup1))
print('tup2: {}'.format(tup2))
print('tup3: {}'.format(tup3))

# ------------------------------------------------------------------------------
# La tercera forma de crear una tupla no es recomendable, ya que puede inducir
# malas prácticas de programación. Cuando declaras una variable y al final 
# agregas una coma, automáticamente se convierte en una tupla:
anio = 2000,
print('anio: {}'.format(anio))

# ------------------------------------------------------------------------------
# Acceder a los elementos de una tupla se hace de la misma forma que una lista:
automovil = ('Chevrolet', 'Corsa', 2020, 'Azul')
print('automovil[1]: {}'.format(automovil[1]))

for caracteristica in automovil:
    print('caracteristica: {}'.format(caracteristica))

# ------------------------------------------------------------------------------
# No puedes modificar los elementos de una lista:
# Ejecuta la siguiente línea.
automovil[2] = 2021

# ------------------------------------------------------------------------------
# Puedes convertir una lista en una tupla y visceversa mediante sus respectivos
# métodos constructores:
auto_list = list(automovil)
auto_list.append('$150000')
print('auto_list: {}'.format(auto_list))

new_auto = tuple(auto_list)
print('new_auto: {}'.format(new_auto))
