# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# En esta práctica vamos a conocer algunos métodos de la clase string o cadena de
# texto, que te van a a servir para responder las actividades siguientes.

# Recuerda que las cadenas de texto están rodeadas por comillas dobles o comillas
# simples, y que puedes crear cadenas de texto con saltos de línea usando tres
# comillas, ya sea dobles o triples.

# Como vimos en las primeras actividades, una cadena de texto se puede iterar
# como una lista:
for letra in 'cadena de texto':
   print('letra: ' + letra)

# Además, puedes acceder a letras dentro de la cadena usando el operador []
cadena = 'cadena de texto'
for i in range(len(cadena)):
   print('letra: ' + cadena[i])

# ------------------------------------------------------------------------------
# Un método muy útil es split(), que recibe de argumento una cadena de texto.
# Este método separa o divide la cadena usando el separador que se usa como
# argumento:
compras = 'huevo,leche,cereal,queso,carne'
for c in compras.split(','):
   print('artículo:', c)

compras = 'huevo,leche,cereal,queso,carne'
for c in compras.split('e'):
   print('artículo:', c)

# ------------------------------------------------------------------------------
# El método replace reemplaza una cadena de texto por otra, si es que existe la
# cadena en el texto a reemplazar.
saludo = 'hola (tu nombre)'
print(saludo.replace('(tu nombre)', 'Luis'))
print(saludo.replace('María', 'Luis'))

# ------------------------------------------------------------------------------
# Una propiedad de las listas en Python son los cortes o slicing mediante el
# operador : (dos puntos). Usando este operador puedes obtener "rebanadas" de la
# cadena de texto:
print('Maestría en Ciencia de Datos'[5:25])

# La sintaxis es: cadena de texo[ posicion inicial : posicion final ] 
# Si se omite la posición inicial entonces se toma el inicio de la cadena por
# defecto. De la misma forma, si se omite la posición final, se considera el
# final de la línea:
print('Maestría en Ciencia de Datos'[:15])
print('Maestría en Ciencia de Datos'[15:])

# Los índices negativos cuentan del final de la cadena hacia el inicio:
print('Maestría en Ciencia de Datos'[:-20])

# En el ejemplo anterior, el 20 negativo en la posición final indica las primeras
# veinte letras de la cadena de texto.

# De igual forma, un valor negativo en la posición inicial indica las últimas
# letras de la cadena de texto.
print('Maestría en Ciencia de Datos'[-15:])

# ------------------------------------------------------------------------------
# El método find recibe como argumento una cadena de texto, y devuelve el índice
# donde se encuentra esa cadena:
print('Maestría en Ciencia de Datos'.find('C'))

# El ejemplo anterior devuelve el valor 12, que es el índice donde se encuentra
# la letra C mayúscula.
# Si la cadena se encuentra más de una vez, el método find sólo devuelve la
# primera ocurrencia:
print('Maestría en Ciencia de Datos'.find('a'))

# Y si la cadena no se encuentra, find devuelve -1:
print('Maestría en Ciencia de Datos'.find('N'))

# Consulta la documentación de Python para entender los argumentos adicionales
# que recibe el método find.
# https://docs.python.org/3/library/stdtypes.html#str.find

# ------------------------------------------------------------------------------
# El método join hace lo contrario que el método split:
print('.'.join('ejemplo'))
print(','.join(['1', 'dos', '3', 'cuatro']))
print('-X-'.join(['1', 'dos', '3', 'cuatro']))

# ------------------------------------------------------------------------------
# Por último, veamos el método format, que da formato a los argumentos que 
# recibe este método. Su forma más simple es la siguiente:
print('Este {} un {} de {}'.format('es', 'ejemplo', 'format'))

# Opcionalmente, puedes numerar los argumentos que recibe el método
print('Este {2} un {0} de {1}'.format('ejemplo', 'format', 'es'))

# El método format es muy poderoso. Revisa la documentación oficial para saber
# todo lo que puedes hacer con este método:
# https://docs.python.org/3.4/library/string.html
