# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Las listas son las estructuras de datos básicas de cualquier lenguaje de 
# programación. En Python una lista puede almacenar valores de cualquier tipo:
lista = [0, 'uno', 2.0, 'III', 4, 'cinco']

# Las listas pueden tener más listas en sus elementos. A esto se le llama
# lista anidada
lista = [0, 'uno', 2.0, 'III', [4.0, 4.1, 4.2, 4.3], 'cinco']

# E incluso anidamiento de más de un nivel
lista = [0, 'uno', 2.0, 'III', [4.0, 4.1, [4.20, 4.21, 4.22, 4.23], 4.3], 'cinco']

# El operador [] permite acceder a elementos de la lista, entre corchetes se
# indica el índice de la lista al que queremos acceder. Este índice debe ser un
# número entero:
print('lista[2]: {}'.format(lista[2]))
print('lista[4]: {}'.format(lista[4]))
print('lista[4][2]: {}'.format(lista[4][2]))
print('lista[4][2][2]: {}'.format(lista[4][2][2]))

# La sentencia for te permite iterar los elementos de una lista:
for elemento in lista:
   print('Elemento: {}'.format(elemento))

# ------------------------------------------------------------------------------
# El método append inserta un elemento al final de la lista:
lista.append(6)
for elemento in lista:
   print('Elemento: {}'.format(elemento))

# Y el método insert recibe como argumento la posición en la lista en la que
# se va a insertar el segundo argumento:
lista.insert(3, 2.999)
print(lista)

# El método remove elimina el elemento de la lista que tenga el valor dado
# como argumento.
lista.remove(2.999)
print(lista)

# El método pop es el contrario al método insert, pero existe otra palabra 
# reservada, -del- que tiene una sintáxis diferente:
del lista[0]
print(lista)

# Usamos el operador de índice ([] - no debe confundirse con una lista
# vacía). La expresión entre corchetes especifica el índice. Recuerda que
# los índices comienzan en 0. Cualquier expresión entera se puede usar como
# índice y, al igual que con las cadenas, los valores de índice negativos
# ubicarán los elementos desde la derecha en lugar de desde la izquierda.

numbers = [17, 123, 87, 34, 66, 8398, 44]
print(numbers[2])
print(numbers[9-8])
print(numbers[-2])

# ------------------------------------------------------------------------------
# Al igual que con las cadenas, la función len devuelve la longitud de una lista 
# (el número de elementos de la lista). Sin embargo, dado que las listas pueden 
# tener elementos que son en sí mismos secuencias (por ejemplo, cadenas). Es 
# importante tener en cuenta que len solo devuelve la longitud más alta.
# Descomenta las siguientes líneas y ejecuta el programa:
alist = ["hello", 2.0, 5]
print(len(alist))
print(len(alist[0]))

# ------------------------------------------------------------------------------
# Recuerda que el primer índice es el punto de inicio del sector y el segundo 
# número es un índice después del final del sector (hasta ese elemento, pero sin 
# incluirlo). Recuerda también que si omite el primer índice (antes de los dos 
# puntos), el segmento comienza al principio de la secuencia. Si omite el segundo 
# índice, el segmento llega al final de la secuencia.
# Descomenta las siguientes líneas y ejecuta el programa:
a_list = ['a', 'b', 'c', 'd', 'e', 'f']
print(a_list[1:3])
print(a_list[:4])
print(a_list[3:])
print(a_list[:])

# ------------------------------------------------------------------------------
# El operador + concatena listas. De manera similar, el operador * repite los
# elementos de una lista un número determinado de veces.
# Descomenta las siguientes líneas y ejecuta el programa:
fruit = ["apple","orange","banana","cherry"]
print([1,2] + [3,4])
print(fruit+[6,7,8,9])
print([0] * 4)

# ------------------------------------------------------------------------------
# Consulta la documentación oficial de Python, o consulta este tutorial:
# https://www.programiz.com/python-programming/methods/list
# para hacer las siguientes operaciones:

# * Obtener el índice de un elemento de la lista
fruit.index('orange')
# * Concatenar otra lista al final
other_fruits = ['watermelon','mango']
fruit.append(other_fruits)
print(fruit)
# * Invertir el órden de la lista
fruit.reverse()
print(fruit)
# * Eliminar todos los elementos de la lista
fruit.clear()
print(fruit)