# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Los diccionarios son estructuras de datos muy poderosas. Puedes verlos como una
# tabla de la forma llave-valor, donde las llaves no se pueden repetir.
# Crear un diccionario es muy fácil:
dict1 = dict()
dict2 = {}

# Para asignar elementos al diccionario se usa el operador [] indicando la llave:
dict1[1] = 'uno'
dict1['0'] = 0
dict1[3.14] = ['PI']
print('dict1: {}'.format(dict1))

# Nota cómo a diferencia de las listas, la llave puede ser de cualquier tipo y
# no necesariamente números enteros. Ya que no es el índice, si no la llave.
# Además, los valores pueden ser de cualquier tipo.

# Te recomendamos siempre usar números enteros o cadenas de texto como llaves,
# ya que usar otros tipos de datos puede degradar el desempeño del programa
# cuando el diccionario es muy grande.

# Si usas el operador [] usando una llave que ya existe, el valor asociado a 
# dicha llave se actualiza:
dict1[1] = 1.0
dict1['0'] = None
print('dict1: {}'.format(dict1))

# Puedes asignar valores iniciales al diccionario cuando lo creas:
dict2 = {'llave1': 'valor1', 'llave2': 'valor2'}
print('dict2: {}'.format(dict2))

# ------------------------------------------------------------------------------
# Puedes acceder a un elemento del diccionario usando el operador []
print("dict2['llave2'] = {}".format(dict2['llave2']))

# Pero el operador arroja un error si la llave no existe:
print("dict2['llave3'] = {}".format(dict2['llave3']))

# Para estos casos puedes usar el método get(), que devuelve None si la llave
# no existe:
print("dict2['llave3'] = {}".format(dict2.get('llave3')))

# El método get() es muy útil. Recibe un segundo parámetro opcional con el valor
# por defecto, en caso de que la llave no exista:
print("dict2['llave3'] = {}".format(dict2.get('llave3', 'No existe')))

# ------------------------------------------------------------------------------
# Los métodos keys(), values() e items() devuelven la lista de llaves, valores
# o ambos elementos, respectivamente:
precios = {
    'cuaderno': 10.5,
    'bolígrafo': 3.0,
    'lápiz': 2.0,
    'libro': 50.0
}
print('precios.keys() = {}'.format(precios.keys()))
print('precios.values() = {}'.format(precios.values()))
print('precios.items() = {}'.format(precios.items()))

# Puedes iterar el diccionario usando los métodos keys() y values():
for key in precios.keys():
   print('Precio de {}: {}'.format(key, precios[key]))

# El método items() devuelve una tupla de la forma (llave-valor):
for key, value in precios.items():
   print('Precio de {}: {}'.format(key, value))

# ------------------------------------------------------------------------------
# El método update de los diccionarios es similar a extend de las listas:
dict1.update(dict2)
print('dic1 actualizado con dict2: {}'.format(dict1))
