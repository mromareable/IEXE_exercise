# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Ya conoces las principales estructuras de datos en Python: listas, diccionarios
# y tuplas. Estas estructuras de datos permiten almacenar múltiples valores en
# una colección.

# El operador "in" evalúa si el valor de la izquierda se encuentra en la colección
# de la derecha.
if 5 in [3, 5, 7]:
   print('encontrado')
else:
   print('no encontrado')

# Puedes usar el operador "not" antes del operador "in" para negar la evaluacion:
if 'x' not in 'abcde':
   print('x no está en abcde')
else:
   print('x si está en abcde')

# También puedes usarlo en tuplas:
colores = ('rojo', 'verde', 'azúl')
if 'negro' in colores:
   print('Negro no es un color válido')

# En el caso de los diccionarios el operador "in" evalúa si el valor está en las
# llaves del diccionario:
precios = {
    'cuaderno': 10.5,
    'bolígrafo': 3.0,
    'lápiz': 2.0,
    'libro': 50.0
}
if 'goma' in precios:
   print('El precio de la goma es: {}'.format(precios['goma']))

# Nota que el operador "in" sólo puede usarse en estructuras de datos:
if 4 in 2:
   print('Error!')

# El error del programa anterior dice:
# TypeError: argument of type 'int' is not iterable
# ¿por qué crees que suceda?
# porque no se puede iterar a través de un integer