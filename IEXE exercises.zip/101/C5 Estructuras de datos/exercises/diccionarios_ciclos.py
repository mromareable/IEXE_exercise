amigos = {'Juan': '90123289', 'Pedro': '10286787', 'Maria': '55782365'}
amigos['Liliana'] = '8967451200'
amigos['Pedro'] = '90123289'

# Para recuperar un valor del diccionario, basta con usar la llave entre corchetes.
print('El telefono de Juan es ' + amigos['Juan'])

# print('El telefono de Luis es ' + amigos['Luis'])
# KeyError: 'Luis'

# La función get determina si el argumento que recibe existe o
# no existe, devuelve “None” en lugar de arrojar un error. 
# Esto nos ayuda a prevenir que el programa se detenga inesperadamente 
# cuando una llave no existe en el diccionario.
print(amigos.get('Luis'))

if 'Luis' not in amigos:
  print('Luis no es un contacto')

familia = {'Mama': '3827016538', 'Papa': '2076183651', 'Hermano': '7619883260'}
# La función update recibe como argumento otro diccionario y lo 
# agrega al diccionario sobre el que se ejecuta la operación.
amigos.update(familia)
# La función keys no recibe ningún argumento y devuelve una lista de las llaves del diccionario.
print('Todos los contatos: ' + str(amigos.keys()))
# La función values no recibe ningún argumento y devuelve una lista con sólo los valores del diccionario.
print('Todos los telefonos: ' + str(amigos.values()))

# La función sorted ordena la lista de llaves del diccionario. 
en_orden = sorted(amigos.keys())

for nombre in en_orden:
  print('El telefono de ' + nombre + ' es ' + amigos[nombre])

# El método items no recibe ningún argumento y devuelve el contenido del diccionario en 
# forma llave, valor, específicamente el método items devuelve una tupla. Una tupla es 
# una lista inmutable, esto es que no se puede alterar ni el tamaño ni el contenido de la tupla.
for nombre, telefono in amigos.items():
  print('El telefono de ' + nombre + ' es ' + telefono)

for datos in amigos.items():
  print('El telefono de ' + datos[0] + ' es ' + datos[1])
