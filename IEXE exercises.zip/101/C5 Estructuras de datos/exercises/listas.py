# Se declara una lista de animales. 
animales = ["perro", "gato", "mamut", "hormiga"]
# Con la función append se agrega un elemento a la lista.
animales.append('oso')
# Se declara una lista de dos aves. 
aves = ["cuervo", "colibri"]
# Con el método extend de la lista para unir 
# la lista de animales con la lista de aves.
animales.extend(aves)
# Con el método insert se inserta un nuevo animal 
# La diferencia con la función append es que el primer argumento 
# es la posición de la lista donde vamos a insertar el nuevo 
# elemento a la lista. Recuerda que los índices empiezan en cero
animales.insert(2, 'mosca')
# Se accede al elemento con índice 1 en la lista, y 
# le asignamos un animal diferente.
animales[1] = 'tigre'
# Con la palabra reservada “del” para eliminar un 
# elemento de la lista, indicando el índice de la lista 
# que queremos eliminar. 
del animales[3]
print(animales)