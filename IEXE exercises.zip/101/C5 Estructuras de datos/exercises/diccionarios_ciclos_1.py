amigos = {'Juan': '90123289', 'Pedro': '10286787', 'Maria': '55782365'}
amigos['Liliana'] = '8967451200'
familia = {'Mama': '3827016538', 'Papa': '2076183651', 'Hermano': '7619883260'}

amigos.update(familia)

en_orden = sorted(amigos.keys())
for nombre in en_orden:
  print('El telefono de ' + nombre + ' es ' + amigos[nombre])

print('='*10)
# La función sorted recibe dos argumentos nombrados opcionales. 
# El argumento reverse es un valor Booleano que le indica a la función sorted que el orden debe ser inverso.
orden_inverso = sorted(amigos.keys(), reverse=True)
for nombre in orden_inverso:
  print('El telefono de ' + nombre + ' es ' + amigos[nombre])

print('='*10)
# El argumento key es un poco más complicado, es una función que le indica al método sorted cómo discriminar
# el orden de una lista. En este caso lo usamos para ordenar nuestro diccionario por el orden de los valores, mediante el método get.
orden_numeros = sorted(amigos.keys(), key=amigos.get)
for nombre in orden_inverso:
  print('El telefono de ' + nombre + ' es ' + amigos[nombre])            