import random
nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Shuffle: revuelve o desordena los 
# elementos de la lista que usa como argumento
random.shuffle(nums) 
# Choice: selecciona al azar un elemento
x = random.choice(nums)
# Sample: obtiene una muestra de la lista
s = random.sample(nums, 4)

