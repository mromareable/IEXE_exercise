# ------------------------------------------------------------------------------
# ============== Bienvenido a la Maestría en Ingeniería en ===============
# ==============        Tecnologías de Información         ===============
# ------------------------------------------------------------------------------

# Crea un diccionario con 1000 elementos, cuya llaves son los primeros 1000
# números naturales (1, 2, 3, 4, 5, 6, 10, ..., 1000). Y el valor de cada llave
# es la cadena de texto de la llave: dict1 = {1: '1', 2: '2', 3: '3', ...}
dict1 = {}  # No cambies el nombre de la variable
for i in range (1,1001):
  dict1[i] = i
print(dict1)

# Escribe un programa en python que combine dos diccionarios en un diccionario
# d3, sumando el valor de las llaves. Por ejemplo:
# d1 = {'a': 10, 'b': 15}
# d2 = {'a': 20, 'c': 5}
# d3 = {'a': 30, 'b': 15, 'c': 5}
d1 = {'A': -9, 'B': 23, 'D': -19, 'E': 4, 'F': -10, 'G': -47, 'H': -18, 'M': -46, 'P': -48, 'Q': -42, 'R': 43, 'S': -31, 'T': -44, 'U': -34, 'X': 47, 'Y': 32}
d2 = {'B': -27, 'C': 27, 'D': 47, 'E': 25, 'H': 24, 'I': -17, 'K': -26, 'M': 13, 'N': 34, 'P': -24, 'T': -10, 'V': 40, 'W': -32, 'X': 36, 'Y': -21, 'Z': 19}
# calcula aquí la suma de los diccionarios
d3 = {} # no cambies el nombre de la variable
d3 = dict(d1)
# for (k,v), (k2,v2) in zip(d1.items(), d2.items()):
for (k,v) in (d2.items()):
    if k in d1:
        d3[k] += v
    else:
        d3[k] = v
print(d3)