class Conjunto():
    def __init__(self,arreglo_1):
        self.arreglo_1 = arreglo_1
    def obtener_conjunto(self):
        final_set=[]
        for i in self.arreglo_1:
            if i not in final_set:
                final_set.append(i)
        print(sorted(final_set))
if __name__ == '__main__':
    oc = Conjunto([3.5,2.5,0.3,-0.2,3.5,0.3])    
    oc.obtener_conjunto() 