class Cola():
    def __init__(self,size):
        self.size = size
        self.cola_o = [] * self.size

    def estado(self):
        cola_s = []
        for i in reversed(self.cola_o):
            cola_s.append(i)
        print(cola_s)

    def sizec(self):
        print("El tamaño de la cola es {}".format(len(self.cola_o))) 

    def put(self,elem):
        self.cola_o.insert(0,elem)
        print("Se ha agregado el elemento {} a la cola".format(elem))
    
    def get(self):
        c_si = len(self.cola_o)
        if (c_si == 0):
            print("No hay elementos que sacar, porque la pila está vacía")
        elif (c_si > 0):
            print("Se ha sacado el elemento {} a la pila".format(self.cola_o.pop()))
    
    def is_empty(self):
        c_size = len(self.cola_o)
        status_v = True
        if (c_size == 0):
            print(status_v)
        elif (c_size > 0):
            status_v = False
            print(status_v)

if __name__ == '__main__':
    c = Cola(4)
    c.is_empty()
    c.get()
    c.put(2)
    c.put(3)
    c.estado()
    c.get()
    c.sizec()