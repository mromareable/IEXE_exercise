import random
from typing import Counter
from warnings import resetwarnings
class Multiplo():
    def __init__(self,numeros):
        self.numeros = numeros
    def regresar_multiplos(self):
        #Listas para guardar los multiplos de 1 o más dígitos
        num_v,num_d = [],[]
        #Lista para guardar los multiplos repetidos
        num_c=[]    
        #For para determinar los multiplos de varios dígitos
        for i in range(2,self.numeros):
            if (self.numeros%i) == 0:
                num_v.append(i)
        #For para determinar los multiplos de 1 dígito
        for j in range(2,9):
            if (self.numeros%j) == 0:
                num_d.append(j)
        #For para determinar los valores de un 1 digito
        for x in num_v:
            for y in num_v:
                if(x*y)==self.numeros:
                    print(str(x)+'*'+str(y)+'='+str(x*y))
                    if(x in num_d):
                        num_c.append(x)
                    elif(y in num_d):
                        num_c.append(y)
        #Funcion programada para contar los valores repetido
        print(dict(Counter(num_c)))
        
if __name__ == '__main__':
    mo = Multiplo(60)
    mo.regresar_multiplos()