class SumarPrimos():
    def __init__(self,numeros):
        self.numeros = numeros

    def obtener_primos(self):
        prime_numbers=[]
        for n in range(1,self.numeros):
            cnt = 0
            for i in range(2,(n//2+1)):
                if(n%i==0):
                    cnt+=1
                    break
            if(cnt == 0 and n != 1):
                prime_numbers.append(n)
        print(prime_numbers)
        return prime_numbers

    def sumar_primos(self):
        sum_List = self.obtener_primos()
        sum_PN = 0
        for i in sum_List:
            sum_PN+=i
        print(sum_PN)


if __name__ == '__main__':
    sp = SumarPrimos(10)
    sp.obtener_primos()
    sp.sumar_primos()

    