class Pila():
    def __init__(self,size):
        self.size = size
        self.pila_o = [] * self.size

    def estado(self):
        pila_s = []
        for i in reversed(self.pila_o):
            pila_s.append(i)
        print(pila_s)

    def sizep(self):
        print("El tamaño de la pila es {}".format(len(self.pila_o))) 

    def push(self,elem):
        self.pila_o.append(elem)
        print("Se ha agregado el elemento {} a la pila".format(elem))
    
    def pop(self):
        p_si = len(self.pila_o)
        if (p_si == 0):
            print("No hay elementos que sacar, porque la pila está vacía")
        elif (p_si > 0):
            print("Se ha sacado el elemento {} a la pila".format(self.pila_o.pop()))
    
    def is_empty(self):
        p_size = len(self.pila_o)
        status_ve = True
        if (p_size == 0):
            print(status_ve)
        elif (p_size > 0):
            status_ve = False
            print(status_ve)

    def is_full(self):
        cnt = 0
        status_vf = True
        pilao=self.pila_o
        for i in pilao:
            cnt+=1
        if(cnt==self.size):
            print(status_vf)
        elif (cnt != self.size):
            status_vf = False
            print(status_vf)

if __name__ == '__main__':
    p = Pila(3)
    p.is_empty()
    p.is_full()
    p.pop()
    p.push(2)
    p.push(3)
    p.estado()
    p.pop()
    p.sizep()