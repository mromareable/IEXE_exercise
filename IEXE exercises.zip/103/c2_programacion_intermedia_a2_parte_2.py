class Cola:

    def __init__(self):
        self.elements = []
    # Mostrar contenido de la cola
    def show(self):
        print(self.elements)
    # Agregar elemento a la entrada de la cola
    def add(self, data):
        self.elements.append(data)
        return data
    # Extraer elemento de la cola por la salida
    def get(self):
        return self.elements.pop(0)
    # Verificar si la cola esta vacia
    def is_empty(self):
        return len(self.elements) == 0

if __name__ == '__main__':
    py_cola = Cola()

# Ingresando el enunciado 'Una cola de uso como ejemplo'
    py_cola.add('Una')
    py_cola.add('cola')
    py_cola.add('de')
    py_cola.add('uso')
    py_cola.add('como')
    py_cola.add('ejemplo')
    py_cola.show()

    py_cola.get() # extrae Una
    py_cola.get() # extrae cola
    py_cola.get() # extrae de
    py_cola.get() # extrae uso
    py_cola.get() # extrae como
    py_cola.get() # extrae ejemplo
# Verifica si la cola esta vacia    
    print(py_cola.is_empty())

    py_cola.add('Una') # regresa Una
    py_cola.add('cola') # regresa cola
    py_cola.add('de') # regresa de
    py_cola.add('uso') # regresa uso
    py_cola.add('como') # regresa como
    py_cola.add('ejemplo') # regresa ejemplo
# Ingresando el enunciado 'Una cola de uso como ejemplo'
    py_cola.show()