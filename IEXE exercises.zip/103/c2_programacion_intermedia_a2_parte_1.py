pila_ej = ['ejemplo', 'de', 'uso', 'de', 'una', 'pila']
print(pila_ej)
# Encuentra el elemento en la pila que se encuentra en 
# la parte superior de la pila y lo regresa, eliminándolo de la pila.
pila_ej.pop(0)
print(pila_ej)
# Agrega un elemento a la pila poniéndolo en la parte superior de la pila.
pila_ej.insert(0,'elemento')
print(pila_ej)
#  Imprime el valor del elemento que se encuentra en la parte 
# superior de la pila, no extrae el elemento.
print(pila_ej[0])
# Verifica si la pila está vacía, regresa True en caso de que 
# la pila esté vacía, False en caso contrario.
print(not len(pila_ej))
# Verifica si la pila está llena, regresa True en caso de que 
# la pila esté llena, False en caso contrario.
print(bool(pila_ej))
