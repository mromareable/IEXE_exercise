from typing import cast
class Tarjeta:
    def __init__(self, banco="banco", numero="0000-0000-0000", titular="john doe",mes_vencimiento="01",anio_vencimiento="2020", cvv=111, tipo_tarjeta="debito"):
        self.banco = banco
        self.numero = numero
        self.titular = titular
        self.mes_vencimiento = mes_vencimiento
        self.anio_vencimiento = anio_vencimiento
        self.cvv = cvv
        self.tipo_tarjeta = tipo_tarjeta
    def compra(self):
        return "se realizó una compra"

class TarjetaDebito(Tarjeta):
    def __init__(self, saldo=1500, cuenta="111-111", monto_min=100,tipo="nomina"):
        Tarjeta.__init__(self)
        self.saldo = saldo
        self.cuenta = cuenta
        self.monto_min = monto_min
        self.tipo = tipo

    def compra_Debito(self,monto_c):
        self.saldo = self.saldo - monto_c
        print(Tarjeta.compra(self))
    def retiro_Debito(self,monto_r):
        self.saldo = self.saldo - monto_r
        print(self.saldo)
    def pago_Debito(self,monto_p):
        self.saldo = self.saldo + monto_p
        print(self.saldo)
    def estado_Cuenta(self):
        print("La cuanta "+self.cuenta+" tiene un saldo de ",self.saldo)


class TarjetaCredito(Tarjeta):
    def __init__(self, saldo=300,limite_credito=10000,cat=21,tipo="oro",dia_corte=23,anualidad=1000):
        self.saldo = saldo
        self.limite_credito = limite_credito
        self.cat = cat
        self.tipo = tipo
        self.dia_corte = dia_corte
        self.anualidad = anualidad

    def compra_Crebito(self,monto_c):
        self.saldo = self.saldo - monto_c
        print(Tarjeta.compra(self))
    def retiro_Crebito(self,monto_r):
        self.saldo = self.saldo - monto_r
        print(self.saldo)
    def deposito_Crebito(self,monto_d):
        self.saldo = self.saldo + monto_d
        print(self.saldo)
    def estado_Cuenta(self):
        monto_pagar = ((self.limite_credito-self.saldo)*100)/10
        print("Esta tarjeta de credito tiene un saldo de ",self.saldo)
        print("Y se le tiene que pagar un monto de ",int(monto_pagar))

class TarjetaPrepago(Tarjeta):
    def __init__(self,saldo=50,fecha_activacion="1970-01-01"):
        self.saldo = saldo
        self.fecha_activacion = fecha_activacion
    def compra_Prepago(self,monto_c):
        self.saldo = self.saldo - monto_c
        print(Tarjeta.compra(self))
    def deposito_Prepago(self,monto_d):
        self.saldo = self.saldo + monto_d
        print(self.saldo)

tarjeta_a = TarjetaDebito()
tarjeta_a.compra_Debito(1000)
tarjeta_a.retiro_Debito(100)
tarjeta_a.pago_Debito(1100)
tarjeta_a.estado_Cuenta()

tarjeta_b = TarjetaCredito()
tarjeta_b.compra_Crebito(150)
tarjeta_b.retiro_Crebito(50)
tarjeta_b.deposito_Crebito(1000)
tarjeta_b.estado_Cuenta()

tarjeta_c = TarjetaPrepago()
tarjeta_c.compra_Prepago(10)
tarjeta_c.deposito_Prepago(100)