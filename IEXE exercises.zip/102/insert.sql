/* -----------------------------------------------------------------------------
======================== BASES DE DATOS RELACIONALES ===========================
----------------------------------------------------------------------------- */

/*  En esta práctica tienes las siguientes tablas disponibles. No es necesario
    que ejecutes las sentencias CREATE.

    CREATE TABLE proveedores (
        id_proveedor SERIAL PRIMARY KEY,
        nombre_compania TEXT NOT NULL,
        nombre_contacto TEXT
    );

    CREATE TABLE productos (
        id_producto SERIAL PRIMARY KEY,
        id_proveedor INTEGER NOT NULL,
        nombre TEXT NOT NULL,
        precio_unitario DOUBLE,
        FOREIGN KEY (id_proveedor) REFERENCES proveedores (id_proveedor)
    );

    Veamos algunos ejemplos de la sentencia INSERT. La sintáxis básica es:
    INSERT INTO <nombre de la tabla> (columnas a insertar)
    VALUES (valores a insertar)

    Los valores a insertar deben de ser en el mismo orden y del mismo tipo que
    los que se especificaron en la lista de columnas. Por ejemplo:
*/

INSERT INTO proveedores (id_proveedor, nombre_compania, nombre_contacto)
VALUES (1, 'Proveedor uno', 'Contacto proveedor uno');

/*  No olvides que tus sentencias SQL deben terminar con ';' para que el programa
    los ejecute correctamente. 

    Nota cómo las llaves primarias de las tablas son de tipo SERIAL, este tipo
    de dato auto incrementa el último valor usado por defecto. Por ejemplo:
*/

INSERT INTO proveedores (nombre_compania, nombre_contacto)
VALUES ('Proveedor dos', 'Contacto proveedor dos');

INSERT INTO proveedores (nombre_compania, nombre_contacto)
VALUES ('Proveedor tres', 'Contacto proveedor tres');

/*  Puedes insertar más de un registro en la misma sentencia INSERT, usando
    más de un conjunto de valores entre paréntesis:
*/

INSERT INTO proveedores (nombre_compania, nombre_contacto) VALUES 
('Proveedor cuatro', 'Contacto proveedor cuatro'),
('Proveedor cinco', 'Contacto proveedor cinco'),
('Proveedor seis', 'Contacto proveedor seis'),
('Proveedor siete', 'Contacto proveedor siete');

/*  Recuerda usar coma "," después de cada conjunto de valores, y un ; al final
    de la sentencia INSERT.
*/

/*  En el caso de la tabla productos, es necesario que tengas cuidado con la
    integridad referencial de la tabla de proveedores a la tabla de productos.
*/

INSERT INTO productos (id_proveedor, nombre, precio_unitario)
VALUES (1, 'Nombre primer producto', 10.0);

/*  De la misma forma, puedes omitir el identificador de la tabla siempre y 
    cuando sea de tipo SERIAL. Y puedes insertar más de un valor en la misma
    sentencia INSERT.
*/

INSERT INTO productos 
(id_proveedor, nombre, precio_unitario) VALUES 
(1, 'Nombre Producto 1, proveedor 1', 10.0),
(1, 'Nombre Producto 2, proveedor 1', 25.0),
(2, 'Nombre Producto 3, proveedor 2', 130.0),
(3, 'Nombre Producto 4, proveedor 3', 50.0);

/*  Intenta insertar un registro que no cumple con la integridad referncial
    y observa el resultado:*/
  
    INSERT INTO productos (id_proveedor, nombre, precio_unitario)
    VALUES (10, 'Proveedor 10 no existe', 10.0);
    

