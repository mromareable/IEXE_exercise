/* -----------------------------------------------------------------------------
======================== BASES DE DATOS RELACIONALES ===========================
----------------------------------------------------------------------------- */

/*  Sigue las instrucciones que se encuentran en el archivo "insert.py". Una vez
    que las tablas se llenen con las sentencias INSERT, regresa a este archivo
    para hacer consultas a la base de datos.

    Ejecuta las siguientes consultas para probar tus sentencias INSERT.

*/
select * from proveedores;

select * from productos;
