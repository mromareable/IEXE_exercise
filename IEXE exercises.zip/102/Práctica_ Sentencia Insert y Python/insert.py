# =============================================================================
# ======================== Bases de Datos Relacionales ========================
# =============================================================================

# Utiliza tus conocimientos de Python para crear un programa que genere múltiples
# sentencias INSERT a las dos tablas de la práctica anterior:
# 
# CREATE TABLE proveedores (
#     id_proveedor INTEGER PRIMARY KEY,
#     nombre_compania TEXT NOT NULL,
#     nombre_contacto TEXT,
#     fecha_alta DATE
# );
# 
# CREATE TABLE productos (
#     id_producto INTEGER PRIMARY KEY,
#     id_proveedor INTEGER NOT NULL,
#     nombre TEXT NOT NULL,
#     precio_unitario DOUBLE,
#     FOREIGN KEY (id_proveedor) REFERENCES proveedores (id_proveedor)
# );
# 
# No tienes que crear las tablas. Ya existen en la base de datos. 
# 
# Escribe aquí un programa que escriba las sentencias INSERT. Usa ciclos FOR
# y variables para llevar un control de los identificadores de proveedores
# para mantener la integridad referencial en tus tablas.
#
# Usa la biblioteca random para dar variedad al contenido de tus tablas.
#
# Es muy importante que SÓLO ESCRIBAS SENTENCIAS SQL VÁLIDAS. No uses otro tipo
# de mensajes, por que va a fallar la inserción a la base de datos. También
# recuerda terminar todas tus sentencias con ";"
#
# Usa el siguente ejemplo.

import random

list_len = random.randint(1,5)
list_insert, list_insert_1 = [],[]

id_proveedor = 1
nombre_compania = 'ACME'
nombre_contacto = 'Will E. Coyote'
fecha_alta = '2020-01-30'

#print('INSERT INTO proveedores (id_proveedor, nombre_compania, nombre_contacto, fecha_alta) ')
#print("VALUES ({}, '{}', '{}', '{}');".format(id_proveedor, nombre_compania, nombre_contacto, fecha_alta))

# Nota como se usan comillas simples (') alrededor de los valores que son de 
# cadena de texto, lo mismo sucede con las fechas. Usa listas y diccionarios para
# llevar un control de proveedores y productos.

id_producto = 1
nombre = 'Pintura'
precio_unitario = 99.45
#print('INSERT INTO productos (id_producto, id_proveedor, nombre, precio_unitario) ')
#print("VALUES ({}, {}, '{}', {});".format(id_producto, id_proveedor, nombre, precio_unitario))

for i in range(list_len):
    str_insert = 'INSERT INTO proveedores (id_proveedor, nombre_compania, nombre_contacto, fecha_alta) '
    str_insert_1 = "VALUES {}, '{}', '{}', '{}');".format(id_proveedor, nombre_compania, nombre_contacto, fecha_alta)
    str_insert_2 = str_insert + str_insert_1
    list_insert.append(str_insert_2)

for j in range(list_len):
    str_insert_0 = 'INSERT INTO productos (id_producto, id_proveedor, nombre, precio_unitario) '
    str_insert_01 = "VALUES ({}, {}, '{}', {});".format(id_producto, id_proveedor, nombre, precio_unitario)
    str_insert_02 = str_insert_0 + str_insert_01
    list_insert_1.append(str_insert_02)

# Si hay algún error en tus sentencias INSERT, verifica que uses comillas dobles
# en los campos TEXT y DATE, que existan comas (,) entre cada valor y que todas 
# sentencias terminen con ;
