# -----------------------------------------------------------------------------
# ====================== BASES DE DATOS RELACIONALES ==========================
# -----------------------------------------------------------------------------
# 
# Crea un programa en Python que llene las cinco tablas. Asegúrate de haber 
# completado la práctica de "Insert y Python" para completar esta evaluación.
#
# Escribe las instrucciones SQL necesarias para:
#   - Insertar por lo menos 50 proveedores
#   - Insertar por lo menos 50 clientes
#   - Insertar por lo menos 1000 productos repartidos aleatoriamente entre los
#     distintos proveedores. Asegurate de variar el precio unitario
#   - Insertar por lo menos 100 órdenes repartidas aleatoriamente entre los 
#     distintos clientes
#   - Agregar por lo menos 2 productos a cada órden (Insertar por lo menos 2
#     registros en la tabla orden_productos
#
# No se va a evaluar el contenido de los nombres de la compañia ni de nombres
# de contacto. Tampoco las direcciones de los clientes.
#
# Criterios de Evaluación:
#   - Ejecución correcta de las sentencias INSERT: 3 puntos
#   - Inserción de por lo menos 50 proveedores: 1 punto
#   - Inserción de por lo menos 1000 productos: 1 punto
#   - Inserción de por lo menos 50 clientes: 1 punto
#   - Inserción de por lo menos 100 órdenes: 1 punto
#   - Inserción de por lo menos 2 productos por cada orden: 1 punto
#   - Integridad referencial entre todas las tablas: 2 puntos
#
# Asegúrate de escribir sentencias SQL válidas y terminarlas con ;. Es muy
# importante que no escribas texto que no sea SQL válido, o tendrás errores al
# insertar los datos en las distintas tablas.
#
# -----------------------------------------------------------------------------

import random

# Por ejemplo, primero inserta en la tabla de proveedores:
cn_list = ['Acme Corporation','Umbrella  Corporation','Globex Corporation']
nc_list = ['Sebastian Gonzales','David Herrera','Ana Sofia']
fa_list = ['2021-09-01','2021-10-01','2021-11-24']

# Ciclo para estructurar INSERT proveedores
for i in range(1, 51):
    str_insert = 'INSERT INTO proveedores (id_proveedor, nombre_compania, nombre_contacto, fecha_alta) '
    str_insert_1 = "VALUES ({}, '{}', '{}', '{}');".format(i, random.choice(cn_list), random.choice(nc_list), random.choice(fa_list))
    print(str_insert + str_insert_1)

# Luego inserta en la tabla de productos:
# Listas para INSERT productos
pn_list = ['Cuadro de paisaje','Bolsa de plastico','Caja de carton']

# Ciclo para estructurar INSERT productos
for i in range(1, 1001):
    str_insert = 'INSERT INTO productos (id_producto, id_proveedor, nombre, precio_unitario) '
    str_insert_1 = "VALUES ({}, {}, '{}', {});".format(i,random.randint(1,51), random.choice(pn_list), round(random.uniform(33.33, 66.66), 2))
    print(str_insert + str_insert_1)

# Tabla de clientes
# Lista para INSERT clientes
ncl_list = ['Sebastian Herrera','David Gonzales','Ana Garcia']
d_list = ['Calle 09','Calle 10','Calle 11']

# Ciclo para estructurar INSERT clientes
for i in range(1, 51):
    str_insert = 'INSERT INTO clientes (id_cliente, nombre_compania, nombre_contacto, direccion) '
    str_insert_1 = "VALUES ({}, '{}', '{}', '{}');".format(i, random.choice(cn_list), random.choice(ncl_list), random.choice(d_list))
    print(str_insert + str_insert_1)

# Ahora inserta una orden relacionada a ese cliente
# Lista para INSERT ordenes
fo_list = ['2021-12-01','2021-12-13','2021-12-24']
# Ciclo para estructurar INSERT ordenes
for i in range(1, 101):
    str_insert = 'INSERT INTO ordenes (id_orden, id_cliente, fecha_orden) '
    str_insert_1 = "VALUES ({}, {}, '{}');".format(i, random.randint(1, 51), random.choice(fo_list))
    print(str_insert + str_insert_1)

# Por último, inserta el detalle de esta orden_producto
# Ciclo para estructurar INSERT orden_producto
for i in range(1, 101):
    for pdct_ordn in range(random.randint(2, 10)):
        pdcts = []
        id_pdct = random.randint(1, 1001)
        while id_pdct in pdcts:
            id_pdct = random.randint(1, 1001)
        pdcts.append(id_pdct)
        str_insert = 'INSERT INTO orden_productos (id_orden, id_producto, cantidad) '
        str_insert_1 = "VALUES ({}, {}, {});".format(i, id_pdct, random.randint(0,50))
        print(str_insert + str_insert_1)
# TIP: En tu practica crea el detalle de cada orden en un ciclo anidado dentro del ciclo que
# crea las órdenes.
