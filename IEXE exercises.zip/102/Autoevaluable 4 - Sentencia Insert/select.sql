/* -----------------------------------------------------------------------------
======================== BASES DE DATOS RELACIONALES ===========================
----------------------------------------------------------------------------- */

/* Prueba aquí tus sentencias INSERT.
*/

SELECT * FROM proveedores;
SELECT * FROM productos;
SELECT * FROM clientes;
SELELCT * FROM ordenes;
SELECT * FROM orden_productos;
